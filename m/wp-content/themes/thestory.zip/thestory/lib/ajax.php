<?php
/**
 * Includes AJAX request handler functions.
 */

